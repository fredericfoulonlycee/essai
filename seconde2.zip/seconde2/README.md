# Fichiers du carnet d'exercice

Pour voir le fichier jupyter de l'exercice 0 cliquer sur [![Binder](https://mybinder.org/badge.svg)](https://mybinder.org/v2/gh/py-math/seconde2/master?filepath=Exercice0.ipynb)
