# importation des librairies
from PIL import Image

# ouverture du fichier image
ImageFile = 'hawkeye.jpg'
img = Image.open(ImageFile)

# r�cup�ration de la largeur et hauteur de l'image
colonne,ligne = img.size

# cr�ation d'une image de m�me type
imgF = Image.new(img.mode,img.size)

#boucle de traitement des pixels
for i in range(ligne):
   for j in range(colonne):
        pixel = img.getpixel((j,i))
        imgF.putpixel((colonne-j-1,i), pixel)

# la fonction de PIL qui fait la m�me chose
#imgF = img.transpose(Image.FLIP_LEFT_RIGHT)     

# affichage de l'image
imgF.show()

# fermeture du fichier image
img.close()




