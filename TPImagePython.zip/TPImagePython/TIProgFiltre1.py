from PIL import Image

# ouverture du fichier image
ImageFile = 'hawkeye.jpg'
img = Image.open(ImageFile)

# r�cup�ration de la largeur et hauteur de l'image
colonne,ligne = img.size

# cr�ation d'une image de m�me type
imgF = Image.new(img.mode,img.size)

#boucle de traitement des pixels
for i in range(ligne):
   for j in range(colonne):
        pixel = img.getpixel((j,i))
        # filtrage couleur - filtre vert
        p = (0,pixel[1],0)
        imgF.putpixel((j,i), p)

# affichage de l'image
imgF.show()

# fermeture du fichier image
img.close()




