# importation des librairies
from PIL import Image,ImageChops

# ouverture du fichier image
ImageFile = 'hawkeye.jpg'
img = Image.open(ImageFile)

# r�cup�ration de la largeur et hauteur de l'image
colonne,ligne = img.size

# cr�ation d'une image de m�me type
imgF = Image.new(img.mode,img.size)

#boucle de traitement des pixels
for i in range(ligne):
    for j in range(colonne):
        pixel = img.getpixel((j,i))
        # on calcule le complement � MAX pour chaque composante - effet n�gatif
        p = (255 - pixel[0], 255 - pixel[1], 255 - pixel[2])
        # composition de la nouvelle image
        imgF.putpixel((j,i), p)

# la fonction de PIL qui fait la m�me chose
#imgF = ImageChops.invert(img)     

# affichage de l'image
imgF.show()

# fermeture du fichier image
img.close()
